# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 13:06:27 2018

@author: mwahab
"""

iterations = 3000
learning_rate = 0.2
hidden_nodes = 15
output_nodes = 1
